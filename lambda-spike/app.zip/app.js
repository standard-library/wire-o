// 'use strict';

const exec = require('child_process').exec;

process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT'] + '/bin';
process.env['LD_LIBRARY_PATH'] = process.env['LAMBDA_TASK_ROOT'] + '/bin';

const pm = require('pdf-merge');
const request = require('request');
const async = require('async');

exports.handler = function(event, context) {
  console.log('hi');
  console.log(event);
// for (var i in event) {
//   console.log(event[i]);
// }


  // api would get the pdf as base 64
  // so this is mimicking that for now until have something set up locally
  // http://stackoverflow.com/questions/2820249/base64-encoding-and-decoding-in-client-side-javascript

  // var request = require('request').defaults({ encoding: null });

  // var pdfUrls = [];
  // var url1 = 'https://s3-us-west-2.amazonaws.com/pdftestspike/PCAH_PDF_TEMPLATE.pdf';
  // var url2 = 'https://s3-us-west-2.amazonaws.com/pdftestspike/cat+in+the+hat.pdf';


  // async.each()
  // var PdfConverter = function(url) {
  //   convertToBytes: function() {
  //     request.get(url, function (error, response, body) {
  //       if (!error && response.statusCode == 200) {
  //         var data = "data:" + response.headers["content-type"] + ";base64," + new Buffer(body).toString('base64');
  //         console.log(data);
  //       }
  //     });
  //   }
  // }

  // PdfConverter.convertToBytes(url1);
  // PdfConverter.convertToBytes(url2);

  // exec('pdftk --version', context.done);

}
