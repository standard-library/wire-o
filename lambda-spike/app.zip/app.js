'use strict';

const exec = require('child_process').exec;

process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT'] + '/bin';
process.env['LD_LIBRARY_PATH'] = process.env['LAMBDA_TASK_ROOT'] + '/bin';

const pdfMerge = require('pdf-merge');
const request = require('request');
const async = require('async');
const zlib = require('zlib');
const fs = require('fs');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const uuid = require('node-uuid');
// const targz = require('tar.gz');
// const tar = require('tar');
// const unzip = require('unzip');

exports.handler = function(event, context) {

  const base64Data = event.data;

  async.each(base64Data, function (pdfData, callback) {
    let buff = new Buffer(pdfData, 'base64');
    zlib.unzip(buff, function (err, buffed) {
      if (!err) {
        const params = { Bucket: 'superglue', Key: uuid.v4() + ".pdf", Body: buffed };
        s3.putObject(params, function (err, s3Data) {
          if (err) {
            console.log(err);
          } else {
            console.log('s3 data: ' + s3Data)
            console.log('Successfully uploaded.');
          }
        });
      } else {
        console.log('error');
      }
    });
  });
}


  // for (var i in base64Data) {
  //
  //   let buff = new Buffer(base64Data[i], 'base64');
  //
  //   zlib.unzip(buff, (err, buffer) =>
  //     if (!err) {
  //       const params = { Bucket: 'superglue', Key: i + ".pdf", Body: buffer };
  //
  //       s3.putObject(params, function(err, data) {
  //         if (err) {
  //           console.log(err);
  //         } else {
  //           console.log("Successfully uploaded.")
  //         }
  //       });
  //
  //     } else {
  //       console.log('error');
  //     }
  //   });
  // }

// async.each(event.Records, function (record, callback) {
//     var kinesisStream = record.eventSourceARN.split("/")[1];
//     var kinesisShard = record.eventID.split(":")[0];
//     var rec = new Buffer(record.kinesis.data, 'base64');
//     zlib.unzip(rec, function (err, data) {
//         if (!err) {
//             extractData(data, kinesisStream, kinesisShard, function (err, records) {
//                 sendToKinesis(records, function (err, msg) {
//                     if (!err) {
//                         callback();
//                     } else {
//                         console.error("Error : " + JSON.stringify(err));
//                         callback(null, err);
//                     }
//                 })
//             });
//         }
//         else {
//             console.error("unzip error: " + err, err.stack);
//             callback(null, err);
//         }
//     });
// }, function (err) {
//     if (err) {
//         context.done("some error occured");
//     } else {
//         // console.log("i m done");
//         RecordMetrics("ForwardedEvents", messagesSent, event.Records.length, function (err, data) {
//             // console.log("ForwardedEvents metric sent to CloudWatch");
//             context.done();
//         });
//     }
// });
