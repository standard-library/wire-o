'use strict';

var exec = require('child_process').exec;

process.env['PATH'] = process.env['PATH'] + ':' + process.env['LAMBDA_TASK_ROOT'] + '/bin';
process.env['LD_LIBRARY_PATH'] = process.env['LAMBDA_TASK_ROOT'] + '/bin';

var pdfMerge = require('pdf-merge');
var request = require('request');
var async = require('async');
var zlib = require('zlib');
var fs = require('fs');
var AWS = require('aws-sdk');
var s3 = new AWS.S3();
var uuid = require('node-uuid');
// var targz = require('tar.gz');
// var tar = require('tar');
// var unzip = require('unzip');

exports.handler = function(event, context) {

// TAKE POST REQUEST TAR.GZ FILES, UNGZIP THEM, AND SEND TO S3
  // var base64Data = event.data;
  // async.each(base64Data, function (pdfData, callback) {
  //   var buff = new Buffer(pdfData, 'base64');
  //   zlib.unzip(buff, function (err, buffed) {
  //     if (!err) {
  //       var params = { Bucket: 'superglue', Key: uuid.v4() + '.pdf', Body: buffed };
  //       s3.putObject(params, function (err, s3Data) {
  //         if (err) {
  //           console.log(err);
  //         } else {
  //           console.log('s3 data: ' + s3Data)
  //           console.log('Successfully uploaded.');
  //         }
  //       });
  //     } else {
  //       console.log('error');
  //     }
  //   });
  // });

  // TAKE POST REQUEST TAR.GZ FILES, UNGZIP THEM, AND SAVE THEM TO /tmp

  var base64Pdfs = event.data;
  async.each(base64Pdfs, function (base64Pdf, callback) {
    var pdfBuffer = new Buffer(base64Pdf, 'base64');
    zlib.unzip(pdfBuffer, function (err, buffer) {
      if (!err) {
        writeToTmp(buffer);
        console.log('File unzipped');
        callback();
      } else {
        callback('Error unzipping file.');
      }
    });
  }, function(err) {
    if (err) {
      console.log('File did not process.');
    } else {
      console.log('All files processed');
    }
  });

  function writeToTmp(buffer, callback) {
    var filePath = '/tmp/' + uuid.v4() + '.pdf'
    fs.writeFile(filePath, buffer, function (err) {
      if (err) return console.log(err);
      console.log('worked!?');
    });
  }

  // function mergeTmpFiles() {
  //
  // }


// GET PDFS FROM S3
  // var params = { Bucket: 'superglue', Key: '8db59808-9b5b-4d52-b647-6a1e235f5ec7.pdf' };
  // s3.getObject(params, function (err, data) {
  //   if (err) {
  //     console.log(err);
  //   } else {
  //     // console.log('data: ' + data);
  //     for (var i in data) {
  //       console.log(data[i]);
  //     }
  //   }
  // });



// PDF MERGE STUFF
  // var PDFMerge = require('pdf-merge');
  // var pdftkPath = './bin/pdftk'
  // var pdftkPath = 'C:\\PDFtk\\bin\\pdftk.exe';
  // var pdfFiles = [__dirname + '/pdf1.pdf', __dirname + '/pdf2.pdf'];
  // var pdfMerge = new PDFMerge(pdfFiles, pdftkPath);

  // pdfMerge
  //   .asBuffer()
  //   .merge(function(error, buffer) {
  //fs.writeFileSync(__dirname + '/merged.pdf', buffer);
// });

}
